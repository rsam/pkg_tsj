/* @ver. 2.0.3 */

/* Add default value*/
AFTER TABLE `#__tsj_tarif` ADD COLUMN `tarif_type` INT(1) NULL AFTER 'tarif_2';
