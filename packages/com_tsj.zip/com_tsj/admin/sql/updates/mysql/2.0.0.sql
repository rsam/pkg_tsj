/* @ver. 2.0.0 */

/* Add default value*/
INSERT INTO `#__tsj_cfg`(`cfg_name`, `cfg_value`)
VALUES ('gaz_linksn','');

INSERT INTO `#__tsj_cfg`(`cfg_name`, `cfg_value`)
VALUES ('gaz_prefix_text','');

INSERT INTO `#__tsj_cfg`(`cfg_name`, `cfg_value`)
VALUES ('gaz_startDay','1');

INSERT INTO `#__tsj_cfg`(`cfg_name`, `cfg_value`)
VALUES ('gaz_stopDay','31');

INSERT INTO `#__tsj_cfg`(`cfg_name`, `cfg_value`)
VALUES ('electro_linksn','');

INSERT INTO `#__tsj_cfg`(`cfg_name`, `cfg_value`)
VALUES ('electro_prefix_text','');

INSERT INTO `#__tsj_cfg`(`cfg_name`, `cfg_value`)
VALUES ('electro_startDay','1');

INSERT INTO `#__tsj_cfg`(`cfg_name`, `cfg_value`)
VALUES ('electro_stopDay','31');