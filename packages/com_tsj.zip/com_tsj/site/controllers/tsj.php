<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla controllerform library
jimport('joomla.application.component.controllerform');

/**
 * Controller
 */
class TSJControllerTSJ extends JControllerForm
{
	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	/*function __construct()
	 {
	 parent::__construct();
	  
	 // Регистрация дополнительных задач
	 //$this->registerTask('add', 'edit');
	 //$this->setRedirect(JRoute::_('index.php?option=com_tsj&view=lic&layout=default&id='.JFactory::getUser()->id, false));
	 }*/
}