<?php die(); ?>

COPYRIGHT AND DISCLAIMER
------------------------
TSJ Component is Mgt.Co & HOA solution for Joomla 2.5.X!
Copyright (C) 2012  Shibin Roman 

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but without any warranty; without even the implied warranty of
merchantability or fitness for a particular purpose.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

The full text of the license can be found in the license.txt file inside all of
our ZIP packages.

CONTACT AND SUPPORT
-------------------
If you have further questions or need support, you can contact the author directly by emailing
at rsa_m@mail.ru. Alternatively or send a Google+ message to Shibin Roman.

DOCUMENTATION AND DOWNLOADS
---------------------------
The full documentation is provided free of charge to all. You can find the
documentation on-line in the Doc section of GIT https://github.com/rsam/com_tsj.git.

You can load current version component of GIT https://github.com/rsam/com_tsj.git always.
If you detect any bug, please use bug report of GIT.

You can add issues of GIT https://github.com/rsam/com_tsj/issues always.
