<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>

<tr>
	<th width="100%"><?php
	// Вывод идентификатора пользователя
	echo JText::_('<h2>Ваш идентификатор пользователя : ' . $this->user . '</h2><br>');
	echo JText::_('<h2>Серийные номера счетчиков газа</h2>');
	?>
	</th>
</tr>
