/* @ver. 1.1.0 */

/* Add default value*/
INSERT INTO `#__tsj_cfg`(`cfg_name`, `cfg_value`)
VALUES ('water_linksn','');

INSERT INTO `#__tsj_cfg`(`cfg_name`, `cfg_value`)
VALUES ('water_prefix_text','');

INSERT INTO `#__tsj_cfg`(`cfg_name`, `cfg_value`)
VALUES ('water_startDay','1');

INSERT INTO `#__tsj_cfg`(`cfg_name`, `cfg_value`)
VALUES ('water_stopDay','31');
