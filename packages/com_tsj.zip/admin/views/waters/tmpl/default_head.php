<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
	<th><?php echo JText::_('COM_TSJ_WATER_HEADING_NAME'); ?>
	</th>
</tr>
