<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');

JHtml::_('behavior.keepalive');
?>

<tr>
	<td><?php echo JText::_('COM_TSJ_MY_SETTINGS'); ?>
	</td>
</tr>
