<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
	<th width="5"><?php echo JText::_('В разработке'); ?>
	</th>
	<th width="20">
		<!--<input type="checkbox" name="toggle" value="" onclick="checkAll(-->
	<?php //echo count($this->items); ?> <!--);" />-->
	</th>
	<th><?php echo JText::_('COM_TSJ_TSJ_HEADING_NAME'); ?>
	</th>
</tr>
